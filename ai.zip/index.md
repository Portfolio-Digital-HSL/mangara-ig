# Home - v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://mangaradigital.org/fhir/mangara/ImplementationGuide/org.mangaradigital.fhir.mangara | *Version*:0.1.0 |
| Draft as of 2026-10-09 | *Computable Name*:MangaraIG |

# MangaraIG

Guia de Implementação FHIR da Mangara Digital (HSL).

## Visão Geral

Este guia descreve os perfis, extensões, exemplos e regras de conformidade utilizados nas integrações FHIR do projeto.

## Conteúdo

* [Sobre o Guia](sobre-o-guia.md)
* [Escopo e Casos de Uso](escopo-e-casos-de-uso.md)
* [Perfis](perfis.md)
* [Extensões](extensoes.md)
* [Exemplos](exemplos.md)
* [Conformidade e Validação](conformidade-e-validacao.md)
* [Versionamento e Mudanças](versionamento-e-mudancas.md)

