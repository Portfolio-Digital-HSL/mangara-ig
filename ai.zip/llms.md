# org.mangaradigital.fhir.mangara#0.1.0: null

## Pages

* [Home](index.md)
* [Conformidade E Validacao](conformidade-e-validacao.md)
* [Extensoes](extensoes.md)
* [Sobre O Guia](sobre-o-guia.md)
* [Versionamento E Mudancas](versionamento-e-mudancas.md)
* [Artifacts Summary](artifacts.md)
* [Escopo E Casos De Uso](escopo-e-casos-de-uso.md)
* [Perfis](perfis.md)
* [Exemplos](exemplos.md)

## Resources

### Resource Profiles

* [PractitionerRole Mangara](StructureDefinition-practitioner-role-mangara.md)

### Extensions

* [Duração da consulta Mangara](StructureDefinition-duracao-consulta-mangara.md)

### ImplementationGuides

* [MangaraIG](index.md)
