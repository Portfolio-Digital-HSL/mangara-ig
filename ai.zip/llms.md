# org.mangaradigital.fhir.mangara#0.1.0: null

## Pages

* [Home](index.md)
* [Extensoes](extensoes.md)
* [Perfis](perfis.md)
* [Sobre O Guia](sobre-o-guia.md)
* [Exemplos](exemplos.md)
* [Artifacts Summary](artifacts.md)
* [Escopo E Casos De Uso](escopo-e-casos-de-uso.md)
* [Versionamento E Mudancas](versionamento-e-mudancas.md)
* [Conformidade E Validacao](conformidade-e-validacao.md)

## Resources

### Resource Profiles

* [Paciente Mangará](StructureDefinition-patient-mangara.md)
* [PractitionerRole Mangara](StructureDefinition-practitioner-role-mangara.md)

### Extensions

* [Duração da consulta Mangara](StructureDefinition-duracao-consulta-mangara.md)

### ImplementationGuides

* [MangaraIG](index.md)

### Examples

* [paciente-cpf-cns (Patient)](Patient-paciente-cpf-cns.md)
* [paciente-desativado-duplicidade (Patient)](Patient-paciente-desativado-duplicidade.md)
* [paciente-estrangeiro (Patient)](Patient-paciente-estrangeiro.md)
* [paciente-indigena-aldeia (Patient)](Patient-paciente-indigena-aldeia.md)
* [paciente-portal-nome-social (Patient)](Patient-paciente-portal-nome-social.md)
* [paciente-somente-cns (Patient)](Patient-paciente-somente-cns.md)
